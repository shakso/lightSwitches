var UI = require('ui');
var ajax = require('ajax');
var Vibe = require('ui/vibe');

// Show splash screen while waiting for data
var splashWindow = new UI.Window();

// Text element to inform user
var text = new UI.Text({
  text:'Checking switches...',
  font:'GOTHIC_28_BOLD',
  color:'black',
  textOverflow:'wrap',
  textAlign:'center',
	backgroundColor:'white'
});

// Add to splashWindow and show
splashWindow.add(text);
splashWindow.show();

// Make request to update
function ParseItems(data) {
    var items = [];
  
    for(var i = 0; i < data.hosts.length; i++) {
      var icon;
      if (data.hosts[i].state == 1 ) {
        icon='images/on_color.png';
      } else {
        icon='images/off_color.png';
      }
      
      items.push({
        title:data.hosts[i].name,
        icon: icon
      });
    }
  return items;
}

ajax(
    {
      url:'http://192.168.1.2/?discover',
      type:'json'
    },
    function(data) {
    var items=ParseItems(data);

    // Construct Menu to show to user
    var resultsMenu = new UI.Menu({
      sections: [{
        title: 'Switches',
        items: items
      }]
    });

    resultsMenu.show();
    splashWindow.hide();
    resultsMenu.on('select', function(e) {
      var status;
      if (e.item.icon == 'images/on_color.png') {
        status = 'off';
      } else {
        status = 'on';
      }
      ajax(
        {
          url:'http://192.168.1.2/?' + e.item.title + ':' + status,
          type:'json'
        },
        function(data) {
          setTimeout(function() {
          ajax(
            {
              url:'http://192.168.1.2/?discover',
              type:'json'
            },
            function(data) {
              var newItems=ParseItems(data);
              resultsMenu.items(0,newItems);
            });
          }, 500);
        });
    });
  },
  function(error) {
    console.log('Download failed: ' + error);
  }
);
